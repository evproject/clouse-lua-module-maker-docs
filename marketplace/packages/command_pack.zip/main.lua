﻿local module = {
  id = "command_pack",
  name = "Command Pack",
  prefix = "."
}

function module.on_command(ctx, args)
  local sub = args[1] or "status"
  if sub == "status" then
    local player = ctx.player()
    ctx.log(module.name .. " ready for " .. player.name)
    return true
  end
  return false
end

return module
