﻿local module = {
  id = "config_tool",
  name = "Config Tool"
}

module.state = { runs = 0 }

function module.on_load(ctx)
  module.state = ctx.import_json("state", module.state)
  ctx.log("Loaded config for " .. module.name)
end

function module.on_tick(ctx)
  if not ctx.setting("enabled", true) then
    return
  end
  module.state.runs = module.state.runs + 1
  if module.state.runs % 2 == 0 then
    ctx.export_json("state", module.state)
  end
end

return module
