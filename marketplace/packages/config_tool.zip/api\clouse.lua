﻿local clouse = {}; return clouse
