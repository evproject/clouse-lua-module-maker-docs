﻿local module = {
  id = "hud_panel",
  name = "HUD Panel",
  accent = 1122867
}

function module.on_render_hud(ctx, draw)
  if not ctx.setting("enabled", true) then
    return
  end
  local player = ctx.player()
  draw.text(12, 12, module.name, module.accent)
  draw.text(12, 24, "Player: " .. player.name, 4294967295)
end

return module
